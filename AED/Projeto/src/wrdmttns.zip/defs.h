#ifndef _DEFS_H
#define _DEFS_H

typedef void *Item;

#endif